
public interface IProblema {

	int oneMax();
	
	int binary_to_decimal();
	
	double get_fitness();
	
	int square();
	
}
